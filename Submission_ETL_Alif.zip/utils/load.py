import pandas as pd
from sqlalchemy import create_engine
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build

def load_to_csv(df, filename="products.csv"):
    try:
        df.to_csv(filename, index=False)
        print(f"Data berhasil disimpan ke {filename}")
    except Exception as e:
        print(f"Error menyimpan ke CSV: {e}")

def load_to_postgres(df, db_url="postgresql://developer:password@localhost:5432/booksdb"):
    # Ganti kredensial db_url sesuai dengan settingan lokal lu
    try:
        engine = create_engine(db_url)
        df.to_sql("fashion_competitor", engine, if_exists='replace', index=False)
        print("Data berhasil disimpan ke PostgreSQL")
    except Exception as e:
        print(f"Error menyimpan ke PostgreSQL: {e}")

def load_to_gsheets(df, spreadsheet_id, range_name="Sheet1!A1"):
    try:
        # Syarat wajib: file google-sheets-api.json harus ada di folder utama
        SCOPES = ['https://www.googleapis.com/auth/spreadsheets']
        creds = Credentials.from_service_account_file('google-sheets-api.json', scopes=SCOPES)
        service = build('sheets', 'v4', credentials=creds)
        
        # Siapkan data (Header + Isi baris)
        # G-Sheets butuh data dalam bentuk list of lists, dan tipe data khusus seperti timestamp harus diubah ke string
        df_copy = df.copy()
        df_copy['timestamp'] = df_copy['timestamp'].astype(str)
        
        values = [df_copy.columns.values.tolist()] + df_copy.values.tolist()
        body = {'values': values}
        
        result = service.spreadsheets().values().update(
            spreadsheetId=spreadsheet_id, range=range_name,
            valueInputOption="RAW", body=body
        ).execute()
        
        print(f"Data berhasil disimpan ke Google Sheets. {result.get('updatedCells')} cells updated.")
    except Exception as e:
        print(f"Error menyimpan ke Google Sheets: {e}")